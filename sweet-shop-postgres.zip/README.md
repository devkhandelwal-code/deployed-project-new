# Sweet Shop Management System (Postgres)

This is a ready-to-run full-stack Sweet Shop project (backend + frontend) configured for **PostgreSQL**.

## Quick start (backend)
1. Install dependencies:
   ```
   cd backend
   npm install
   ```
2. Copy `.env.sample` to `.env` and update `DATABASE_URL` with your Postgres connection string. Example:
   ```
   DATABASE_URL="postgresql://postgres:postgres@localhost:5432/sweetshop?schema=public"
   JWT_SECRET="your_jwt_secret"
   PORT=4000
   ```
3. Generate Prisma client and run migrations:
   ```
   npx prisma generate
   npx prisma migrate dev --name init
   ```
4. Start backend:
   ```
   npm run dev
   ```
5. Run tests:
   ```
   npm test
   ```

## Quick start (frontend)
1. Open a new terminal:
   ```
   cd frontend
   npm install
   npm run dev
   ```
2. Open the frontend (Vite) URL shown in terminal (default http://localhost:5173).

## Notes
- The project uses JWT auth. Register a user via `/api/auth/register`. To create an admin create a user in the DB and set `role='admin'` or use the tests which create an admin.
- Tests use the same database; consider using a separate test database in CI.

## My AI Usage
I used ChatGPT during development to scaffold the project, produce tests, and outline the TDD approach. Add `Co-authored-by` trailers in commits where AI was used.

