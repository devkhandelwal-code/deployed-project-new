import { Request, Response } from "express";
import { PrismaClient } from "@prisma/client";
import { AuthRequest } from "../middleware/auth";
const prisma = new PrismaClient();

export const listSweets = async (req: Request, res: Response) => {
  const sweets = await prisma.sweet.findMany();
  res.json(sweets);
};

export const searchSweets = async (req: Request, res: Response) => {
  const { name, category, minPrice, maxPrice } = req.query as any;
  const where: any = {};
  if (name) where.name = { contains: name, mode: "insensitive" };
  if (category) where.category = { equals: category, mode: "insensitive" };
  if (minPrice || maxPrice) {
    where.price = {};
    if (minPrice) where.price.gte = parseFloat(minPrice);
    if (maxPrice) where.price.lte = parseFloat(maxPrice);
  }
  const sweets = await prisma.sweet.findMany({ where });
  res.json(sweets);
};

export const createSweet = async (req: Request, res: Response) => {
  const { name, category, price, quantity } = req.body;
  if (!name || price == null || quantity == null) return res.status(400).json({ error: "Missing fields" });
  const sweet = await prisma.sweet.create({ data: { name, category, price: Number(price), quantity: Number(quantity) } });
  res.status(201).json(sweet);
};

export const updateSweet = async (req: Request, res: Response) => {
  const id = req.params.id;
  const { name, category, price, quantity } = req.body;
  try {
    const sweet = await prisma.sweet.update({
      where: { id },
      data: { name, category, price: price != null ? Number(price) : undefined, quantity: quantity != null ? Number(quantity) : undefined }
    });
    res.json(sweet);
  } catch (err) {
    return res.status(404).json({ error: "Sweet not found" });
  }
};

export const deleteSweet = async (req: Request, res: Response) => {
  const id = req.params.id;
  try {
    await prisma.sweet.delete({ where: { id } });
    res.status(204).send();
  } catch (err) {
    return res.status(404).json({ error: "Sweet not found" });
  }
};

export const purchaseSweet = async (req: AuthRequest, res: Response) => {
  const sweetId = req.params.id;
  const { quantity } = req.body;
  const qty = Number(quantity || 1);
  if (qty <= 0) return res.status(400).json({ error: "Quantity must be positive" });

  const sweet = await prisma.sweet.findUnique({ where: { id: sweetId } });
  if (!sweet) return res.status(404).json({ error: "Sweet not found" });
  if (sweet.quantity < qty) return res.status(400).json({ error: "Insufficient stock" });

  // Simple transaction
  const total = sweet.price * qty;
  await prisma.$transaction([
    prisma.sweet.update({ where: { id: sweetId }, data: { quantity: sweet.quantity - qty } }),
    prisma.purchase.create({ data: { userId: req.user!.id, sweetId, quantity: qty, total } })
  ]);
  res.json({ success: true, total, remaining: sweet.quantity - qty });
};

export const restockSweet = async (req: Request, res: Response) => {
  const sweetId = req.params.id;
  const { quantity } = req.body;
  const qty = Number(quantity);
  if (!qty || qty <= 0) return res.status(400).json({ error: "Quantity must be positive" });
  try {
    // fetch current, then update (works with Postgres)
    const s = await prisma.sweet.findUnique({ where: { id: sweetId } });
    if (!s) return res.status(404).json({ error: "Sweet not found" });
    const sweet = await prisma.sweet.update({ where: { id: sweetId }, data: { quantity: s.quantity + qty } });
    res.json(sweet);
  } catch (err) {
    return res.status(404).json({ error: "Sweet not found" });
  }
};
