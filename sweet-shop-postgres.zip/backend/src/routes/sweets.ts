import { Router } from "express";
import { authenticate, requireRole } from "../middleware/auth";
import {
  createSweet,
  listSweets,
  searchSweets,
  updateSweet,
  deleteSweet,
  purchaseSweet,
  restockSweet
} from "../controllers/sweetsController";

const router = Router();

router.get("/", listSweets);
router.get("/search", searchSweets);

// Protected
router.post("/", authenticate, requireRole("admin"), createSweet);
router.put("/:id", authenticate, requireRole("admin"), updateSweet);
router.delete("/:id", authenticate, requireRole("admin"), deleteSweet);

router.post("/:id/purchase", authenticate, purchaseSweet);
router.post("/:id/restock", authenticate, requireRole("admin"), restockSweet);

export default router;
