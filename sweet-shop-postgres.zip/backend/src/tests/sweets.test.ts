import request from "supertest";
import app from "../app";
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
const prisma = new PrismaClient();

let adminToken: string;
let userToken: string;
let sweetId: string;

beforeAll(async () => {
  await prisma.purchase.deleteMany();
  await prisma.sweet.deleteMany();
  await prisma.user.deleteMany();

  const adminHash = await bcrypt.hash("adminpass", 8);
  const admin = await prisma.user.create({ data: { name: "Admin", email: "admin@example.com", passwordHash: adminHash, role: "admin" } });
  adminToken = jwt.sign({ id: admin.id, email: admin.email, role: admin.role }, process.env.JWT_SECRET || "secret");

  const userHash = await bcrypt.hash("userpass", 8);
  const user = await prisma.user.create({ data: { name: "User", email: "user@example.com", passwordHash: userHash, role: "user" } });
  userToken = jwt.sign({ id: user.id, email: user.email, role: user.role }, process.env.JWT_SECRET || "secret");
});

afterAll(async () => {
  await prisma.$disconnect();
});

describe("Sweets API", () => {
  it("admin can create sweet", async () => {
    const res = await request(app)
      .post("/api/sweets")
      .set("Authorization", `Bearer ${adminToken}`)
      .send({ name: "Gulab Jamun", category: "Traditional", price: 30, quantity: 10 });
    expect(res.statusCode).toBe(201);
    expect(res.body.name).toBe("Gulab Jamun");
    sweetId = res.body.id;
  });

  it("user cannot create sweet", async () => {
    const res = await request(app)
      .post("/api/sweets")
      .set("Authorization", `Bearer ${userToken}`)
      .send({ name: "Ladoo", category: "Traditional", price: 20, quantity: 15 });
    expect(res.statusCode).toBe(403);
  });

  it("list sweets public", async () => {
    const res = await request(app).get("/api/sweets");
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  it("user can purchase sweet", async () => {
    const res = await request(app)
      .post(`/api/sweets/${sweetId}/purchase`)
      .set("Authorization", `Bearer ${userToken}`)
      .send({ quantity: 2 });
    expect(res.statusCode).toBe(200);
    expect(res.body.total).toBeDefined();
  });

  it("admin can restock", async () => {
    const res = await request(app)
      .post(`/api/sweets/${sweetId}/restock`)
      .set("Authorization", `Bearer ${adminToken}`)
      .send({ quantity: 5 });
    expect([200, 201, 204].includes(res.statusCode)).toBeTruthy();
  });

  it("admin can delete", async () => {
    const res = await request(app)
      .delete(`/api/sweets/${sweetId}`)
      .set("Authorization", `Bearer ${adminToken}`);
    expect([200, 204].includes(res.statusCode)).toBeTruthy();
  });
});
