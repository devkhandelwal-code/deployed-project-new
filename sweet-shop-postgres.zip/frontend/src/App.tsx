import React, { useEffect, useState } from "react";
import { Routes, Route, Link } from "react-router-dom";
import Login from "./pages/Login";
import Register from "./pages/Register";
import SweetsList from "./pages/SweetsList";
import AdminPanel from "./pages/AdminPanel";
import { setAuthToken } from "./api";

export default function App() {
  const [token, setToken] = useState<string | null>(localStorage.getItem("token"));
  const [user, setUser] = useState<any>(JSON.parse(localStorage.getItem("user") || "null"));

  useEffect(() => {
    setAuthToken(token);
  }, [token]);

  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setAuthToken(null);
  };

  return (
    <div className="p-4">
      <nav className="flex justify-between mb-4">
        <div>
          <Link to="/">Home</Link>
        </div>
        <div>
          {user ? (
            <>
              <span className="mr-2">Hi, {user.name} ({user.role})</span>
              <button onClick={logout}>Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" className="mr-2">Login</Link>
              <Link to="/register">Register</Link>
            </>
          )}
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<SweetsList />} />
        <Route path="/login" element={<Login onAuth={(t,u) => { setToken(t); setUser(u); localStorage.setItem("token", t); localStorage.setItem("user", JSON.stringify(u)); }} />} />
        <Route path="/register" element={<Register onAuth={(t,u) => { setToken(t); setUser(u); localStorage.setItem("token", t); localStorage.setItem("user", JSON.stringify(u)); }} />} />
        <Route path="/admin" element={<AdminPanel />} />
      </Routes>
    </div>
  );
}
