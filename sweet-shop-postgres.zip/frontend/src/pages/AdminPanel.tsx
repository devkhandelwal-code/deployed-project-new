import React, { useState, useEffect } from "react";
import API from "../api";

export default function AdminPanel() {
  const [sweets, setSweets] = useState<any[]>([]);
  const [form, setForm] = useState({ name: "", category: "", price: 0, quantity: 0 });

  const load = async () => {
    const res = await API.get("/sweets");
    setSweets(res.data);
  };

  useEffect(() => { load(); }, []);

  const add = async (e: any) => {
    e.preventDefault();
    try {
      await API.post("/sweets", form);
      alert("Added");
      setForm({ name: "", category: "", price: 0, quantity: 0 });
      load();
    } catch (err: any) {
      alert(err.response?.data?.error || "Add failed");
    }
  };

  return (
    <div>
      <h2>Admin Panel</h2>
      <form onSubmit={add}>
        <input placeholder="Name" value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
        <input placeholder="Category" value={form.category} onChange={e => setForm({...form, category: e.target.value})} />
        <input placeholder="Price" type="number" value={form.price} onChange={e => setForm({...form, price: Number(e.target.value)})} />
        <input placeholder="Quantity" type="number" value={form.quantity} onChange={e => setForm({...form, quantity: Number(e.target.value)})} />
        <button type="submit">Add Sweet</button>
      </form>

      <h3>Manage Sweets</h3>
      <ul>
        {sweets.map(s => (
          <li key={s.id}>
            {s.name} - Qty: {s.quantity}
            <button onClick={async () => { await API.post(`/sweets/${s.id}/restock`, { quantity: 5 }); load(); }}>Restock +5</button>
            <button onClick={async () => { await API.delete(`/sweets/${s.id}`); load(); }}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
