import React, { useState } from "react";
import API from "../api";
import { useNavigate } from "react-router-dom";

export default function Register({ onAuth }: { onAuth: (token: string, user: any) => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const nav = useNavigate();

  const submit = async (e: any) => {
    e.preventDefault();
    try {
      const res = await API.post("/auth/register", { name, email, password });
      onAuth(res.data.token, res.data.user);
      nav("/");
    } catch (err: any) {
      alert(err.response?.data?.error || "Registration failed");
    }
  };

  return (
    <form onSubmit={submit}>
      <h2>Register</h2>
      <div><input value={name} onChange={e => setName(e.target.value)} placeholder="Name" /></div>
      <div><input value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" /></div>
      <div><input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" /></div>
      <button type="submit">Register</button>
    </form>
  );
}
