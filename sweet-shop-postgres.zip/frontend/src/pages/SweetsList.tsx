import React, { useEffect, useState } from "react";
import API from "../api";

export default function SweetsList() {
  const [sweets, setSweets] = useState<any[]>([]);

  const load = async () => {
    try {
      const res = await API.get("/sweets");
      setSweets(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => { load(); }, []);

  return (
    <div>
      <h2>Available Sweets</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(220px,1fr))", gap: 12 }}>
        {sweets.map(s => (
          <div key={s.id} style={{ border: "1px solid #ddd", padding: 12 }}>
            <h3>{s.name}</h3>
            <div>Category: {s.category}</div>
            <div>Price: ₹{s.price}</div>
            <div>Qty: {s.quantity}</div>
            <button disabled={s.quantity <= 0} onClick={async () => {
              try {
                const token = localStorage.getItem("token");
                if (!token) { alert("Login first"); return; }
                await API.post(`/sweets/${s.id}/purchase`, { quantity: 1 });
                alert("Purchased!");
                load();
              } catch (err: any) {
                alert(err.response?.data?.error || "Purchase failed");
              }
            }}>{s.quantity > 0 ? "Purchase" : "Out of stock"}</button>
          </div>
        ))}
      </div>
    </div>
  );
}
